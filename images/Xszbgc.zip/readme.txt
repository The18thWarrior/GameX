button text: Pawn
primary color: 3366ff
gradient color: 330099
width (pixels): 40
height (pixels): 40
corner radius (pixels): 15
text height (points): 10
text color: 000000
background color: clear
font name: HelvBoldOblique
rollover primary color: 66ffff
rollover gradient color: 6666ff
rollover text color: 000000
quality: 1
image location: none
image height (pixels): 5
image name: 
image foreground color determination: auto
image foreground color: 000000
image transparent color determination: auto
image transparent color: ffffff
url: http://www.glassybuttons.com/glassy.php?button_text=Pawn&amp;color=3366ff&amp;grcolor=330099&amp;width=40&amp;height=40&amp;radius=15&amp;theight=10&amp;tcolor=000000&amp;bkcolor=clear&amp;fname=HelvBoldOblique&amp;rcolor=66ffff&amp;rgrcolor=6666ff&amp;rtcolor=000000&amp;imglocate=none&amp;imgheight=5&amp;imgname=&amp;imgfore=auto&amp;imgforecolor=000000&amp;imgtran=auto&amp;imgtrancolor=ffffff&amp;quality=1&amp;fromhere=1
